import java.util.Map;
/**
 * Ziv Glam
 * 327509105
 * assignment 4.
 */
public class Xnor extends BinaryExpression implements Expression {
    /**
     * constructs a Xnor expression with 2 sub-expressions.
     * @param exp1 expression to the left of the symbol
     * @param exp2 expression to the right of the symbol
     */
    public Xnor(Expression exp1, Expression exp2) {
        super(exp1, exp2);
    }
    /**
     *  Evaluate the expression using the variable values provided in the assignment.
     * @param assignment the entire line of evaluations
     * @return the result of the expression
     * @throws Exception if assignment contains a variable not in the expression.
     */
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        try {
            return this.getExp1().evaluate(assignment) == this.getExp2().evaluate(assignment);
        } catch (Exception exception) {
            return null;
        }
    }
    /**
     * Returns a new expression in which all occurrences of var are replaced with the provided expression.
     * @param var variable in the returned expressions
     * @param expression type of expression that matches var.
     * @return a new expression after the swap
     */
    @Override
    public Expression assign(String var, Expression expression) {
        return new Xnor(this.getExp1().assign(var, expression), this.getExp2().assign(var, expression));
    }
    /**
     * Converts the current expression to Nand.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    @Override
    public Expression nandify() {
        Nand nand1 = new Nand(this.getExp1().nandify(), this.getExp2().nandify());
        Nand nand2 = new Nand(this.getExp1().nandify(), this.getExp1().nandify());
        Nand nand3 = new Nand(this.getExp2().nandify(), this.getExp2().nandify());
        return new Nand(new Nand(nand2, nand3), nand1);
    }
    /**
     * Converts the current expression to Nor.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    @Override
    public Expression norify() {
        return new Nor(new Nor(this.getExp1().norify(),
                new Nor(this.getExp1().norify(), this.getExp2().norify())), new Nor(this.getExp2().norify(),
                new Nor(this.getExp1().norify(), this.getExp2().norify())));
    }
    /**
     * Simplifies the expression.
     * @return  a simplified version of the current expression.
     */
    @Override
    public Expression simplify() {
        Expression exp1Simp = this.getExp1().simplify();
        Expression exp2Simp = this.getExp2().simplify();
        //  Simplifies the expression according to 'xnor' simplification rules.
        if (exp1Simp.equals(exp2Simp)) {
            return new Val(true);
        }
        return new Xnor(exp1Simp, exp2Simp);
    }
    /**
     * Overrides the original toString.
     * @return mathematical way of writing the expression
     */
    @Override
    public String toString() {
        return ("(" + this.getExp1() + " # " + this.getExp2() + ")");
    }
}
