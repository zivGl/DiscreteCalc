import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * Ziv Glam
 * 327509105
 * assignment 4.
 */
public class Val implements Expression {
    private boolean value;
    /**
     * Constructor of a val with a given value.
     * @param value value of val
     */
    public Val(boolean value) {
        this.value = value;
    }
    /**
     * Evaluate the expression using an empty hashMap.
     * @return the result of the expression
     * @throws Exception if assignment contains a variable not in the expression.
     */
    @Override
    public Boolean evaluate() throws Exception {
        return evaluate(new HashMap<>());
    }
    /**
     *  Evaluate the expression using the variable values provided in the assignment.
     * @param assignment the entire line of evaluations
     * @return the result of the expression
     * @throws Exception if assignment contains a variable not in the expression.
     */
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        return value;
    }
    /**
     * Returns a new expression in which all occurrences of var are replaced with the provided expression.
     * @param var variable in the returned expressions
     * @param expression type of expression that matches var.
     * @return a new expression after the swap
     */
    @Override
    public Expression assign(String var, Expression expression) {
        return this;
    }
    /**
     * Converts the current expression to Nand.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    @Override
    public Expression nandify() {
        return this;
    }
    /**
     * Converts the current expression to Nor.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    @Override
    public Expression norify() {
        return this;
    }
    /**
     * Simplifies the expression.
     * @return a simplified version of the current expression.
     */
    @Override
    public Expression simplify() {
        //  No need to simplify a one-value expression.
        return this;
    }
    /**
     * gets the list of variables in the expression.
     * @return list of variables
     */
    @Override
    public List<String> getVariables() {
        return List.of();
    }
    /**
     * Overrides the original equals and compares with another object.
     * @param obj what to compare to
     * @return true if equals, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        // checks if this and object have the same string, which also  takes care of the class identification.
        if (this.toString().compareTo(obj.toString()) == 0) {
            return true;
        }
        return false;
    }
    /**
     * Overrides the original toString.
     * @return mathematical way of writing the expression
     */
    @Override
    public String toString() {
        if (this.value) {
            return "T";
        }
        return "F";
    }
}
