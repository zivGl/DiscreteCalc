import java.util.HashMap;
import java.util.Map;
/**
 * Ziv Glam
 * 327509105
 * assignment 4.
 */
public class ExpressionsTest {
    /**
     * Check if the code works.
     * @param args user params
     */
    public static void main(String[] args) {
        //  Create a hashmap with variables and values.
        Map<String, Boolean> map = new HashMap<>();
        map.put("x", true);
        map.put("y", false);
        map.put("z", true);
        //  Create an expression
        Expression test =  new Xor(new And(new Var("x"), new Val(false)),
                new Or(new Var("y"), new Val(false)));
        //  Prints everything.
        System.out.println(test);
        try {
            System.out.println(test.evaluate(map));
        } catch (Exception e) {
            System.out.println("Could not evaluate Expression because one or more of the variables does not exist"
                    + " inside the hashMap");
            e.fillInStackTrace();
        } finally {
            System.out.println(test.norify());
            System.out.println(test.nandify());
            System.out.println(test.simplify());
            System.out.println(test.assign("x", new Nand(new Var("z"), new Var("y"))));
        }
    }
}