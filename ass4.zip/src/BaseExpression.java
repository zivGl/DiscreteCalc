import java.util.HashMap;
/**
 * Ziv Glam
 * 327509105
 * assignment 4.
 */
public abstract class BaseExpression implements Expression {
    private Expression exp1;
    /**
     * gets ex1.
     * @return this ex1
     */
    protected Expression getExp1() {
        return exp1;
    }
    /**
     * sets ex1.
     * @param exp1 new value of ex1
     */
    protected void setExp1(Expression exp1) {
        this.exp1 = exp1;
    }
    /**
     *  Evaluate the expression using an empty hashMap.
     * @return the result of the expression
     * @throws Exception if assignment contains a variable not in the expression.
     */
    @Override
    public Boolean evaluate() throws Exception {
        return evaluate(new HashMap<>());
    }
    /**
     * Overrides the original equals and compares with another object.
     * @param obj what to compare to
     * @return true if equals, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        // checks if this and object have the same string, which also  takes care of the class identification.
        if (this.toString().compareTo(obj.toString()) == 0) {
            return true;
        }
        return false;
    }
}
