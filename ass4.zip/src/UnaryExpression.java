import java.util.List;

/**
 * Ziv Glam
 * 327509105
 * assignment 4.
 */
public abstract class UnaryExpression extends BaseExpression {
    /**
     * constructs a unary expression with 1 expression.
     * @param exp1 expression of the binary expression
     */
    protected UnaryExpression(Expression exp1) {
        this.setExp1(exp1);
    }
    /**
     * gets the list of variables in the expression.
     * @return list of variables
     */
    @Override
    public List<String> getVariables() {
        return List.of(this.getExp1().getVariables().toString());
    }
    /**
     * Converts the current expression to Nand.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    @Override
    public Expression nandify() {
        return null;
    }
    /**
     * Converts the current expression to Nor.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    @Override
    public Expression norify() {
        return null;
    }
}
