import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * Ziv Glam
 * 327509105
 * assignment 4.
 */
public class Var implements Expression {
    private String expression;
    /**
     * constructor of a variable with a given string.
     * @param expression string representing the variable
     */
    public Var(String expression) {
        this.expression = expression;
    }
    /**
     *  Evaluate the expression using an empty hashMap.
     * @return the result of the expression
     * @throws Exception if assignment contains a variable not in the expression.
     */
    @Override
    public Boolean evaluate() throws Exception {
        return evaluate(new HashMap<>());
    }
    /**
     *  Evaluate the expression using the variable values provided in the assignment.
     * @return the result of the expression
     * @throws Exception if assignment contains a variable not in the expression.
     */
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        try {
            return assignment.get(this.expression);
        } catch (Exception exception) {
            return null;
        }
    }
    /**
     * Returns a new expression in which all occurrences of var are replaced with the provided expression.
     * @param var variable in the returned expressions
     * @param expression type of expression that matches var.
     * @return a new expression after the swap
     */
    @Override
    public Expression assign(String var, Expression expression) {
        // Replace variable with the expression if it matches the var.
        if (this.expression.equals(var)) {
            return expression;
        }
        return this;
    }
    /**
     * Converts the current expression to Nand.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    @Override
    public Expression nandify() {
        return this;
    }
    /**
     * Converts the current expression to Nor.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    @Override
    public Expression norify() {
        return this;
    }
    /**
     * Simplifies the expression.
     * @return a simplified version of the current expression.
     */
    @Override
    public Expression simplify() {
        //  No need to simplify a one-variable expression.
        return this;
    }
    /**
     * gets the list of variables in the expression.
     * @return list of variables
     */
    @Override
    public List<String> getVariables() {
        return List.of(this.expression);
    }
    /**
     * Overrides the original equals and compares with another object.
     * @param obj what to compare to
     * @return true if equals, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        // checks if this and object have the same string, which also  takes care of the class identification.
        if (this.toString().compareTo(obj.toString()) == 0) {
            return true;
        }
        return false;
    }
    /**
     * Overrides the original toString.
     * @return mathematical way of writing the expression
     */
    @Override
    public String toString() {
        return this.expression;
    }
}
