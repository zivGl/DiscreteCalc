import java.util.List;
import java.util.Map;
/**
 * Ziv Glam
 * 327509105
 * assignment 4.
 */
public interface Expression {
    /**
     *  Evaluate the expression using the variable values provided in the assignment.
     * @param assignment the entire line of evaluations
     * @return the result of the expression
     * @throws Exception if assignment contains a variable not in the expression.
     */
    Boolean evaluate(Map<String, Boolean> assignment) throws Exception;
    /**
     *  Evaluate the expression using an empty hashMap.
     * @return the result of the expression
     * @throws Exception if assignment contains a variable not in the expression.
     */
    Boolean evaluate() throws Exception;
    /**
     * Gets the list of variables in the expression.
     * @return list of variables
     */
    List<String> getVariables();
    /**
     * Overrides the original toString.
     * @return mathematical way of writing the expression
     */
    String toString();
    /**
     * Swaps all occurrences of var with the provided expression.
     * @param var variable in the returned expressions
     * @param expression type of expression that matches var.
     * @return a new expression after the swap
     */
    Expression assign(String var, Expression expression);
    /**
     * Converts the current expression to Nand.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    Expression nandify();
    /**
     * Converts the current expression to Nor.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    Expression norify();
    /**
     * Simplifies the expression.
     * @return  a simplified version of the current expression.
     */
    Expression simplify();
}