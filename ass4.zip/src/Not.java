import java.util.Map;
/**
 * Ziv Glam
 * 327509105
 * assignment 4.
 */
public class Not extends UnaryExpression implements Expression  {
    /**
     * constructs a not expression by reversing the value of another expression.
     * @param expression expression to put a 'not' on.
     */
    public Not(Expression expression) {
        super(expression);
    }
    /**
     *  Evaluate the expression using the variable values provided in the assignment.
     * @param assignment the entire line of evaluations
     * @return the result of the expression
     * @throws Exception if assignment contains a variable not in the expression.
     */
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        try {
            return !this.getExp1().evaluate(assignment);
        } catch (Exception exception) {
            return null;
        }
    }
    /**
     * Returns a new expression in which all occurrences of var are replaced with the provided expression.
     * @param var variable in the returned expressions
     * @param expression type of expression that matches var.
     * @return a new expression after the swap
     */
    @Override
    public Expression assign(String var, Expression expression) {
        return new Not(this.getExp1().assign(var, expression));
    }
    /**
     * Converts the current expression to Nand.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    @Override
    public Expression nandify() {
        return new Nand(this.getExp1().nandify(), this.getExp1().nandify());
    }
    /**
     * Converts the current expression to Nor.
     * @return the expression tree resulting from converting all the operations to Nand
     */
    @Override
    public Expression norify() {
        return new Nor(this.getExp1().norify(), this.getExp1().norify());
    }
    /**
     * Simplifies the expression.
     * @return  a simplified version of the current expression.
     */
    @Override
    public Expression simplify() {
        Expression exp1Simp = this.getExp1().simplify();
        boolean exp1IsTrue = exp1Simp.equals(new Val(true));
        boolean exp1IsFalse = exp1Simp.equals(new Val(false));
        //  Simplifies the expression according to 'not' simplification rules.
        if (exp1IsTrue) {
            return new Val(false);
        }
        if (exp1IsFalse) {
            return new Val(true);
        }
        //  If the expression can't be simplified, do nothing.
        return new Not(exp1Simp);
    }
    /**
     * Overrides the original toString.
     * @return mathematical way of writing the expression
     */
    @Override
    public String toString() {
        return "~(" + this.getExp1() + ")";
    }
}
