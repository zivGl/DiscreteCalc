import java.util.List;
/**
 * Ziv Glam
 * 327509105
 * assignment 4.
 */
public abstract class BinaryExpression extends BaseExpression {
    private Expression exp2;
    /**
     * construct a binary expression using 2 expressions.
     * @param exp1 expression from the right
     * @param exp2 expression from the left
     */
    protected BinaryExpression(Expression exp1, Expression exp2) {
        this.setExp1(exp1);
        this.setExp2(exp2);
    }
    /**
     * Sets ex2.
     * @param ex new value of ex2
     */
    protected void setExp2(Expression ex) {
        this.exp2 = ex;
    }
    /**
     * get the expression from the right of the symbol.
     * @return exp2
     */
    public Expression getExp2() {
        return this.exp2;
    }
    /**
     * gets the list of variables in the expression.
     * @return list of variables
     */
    @Override
    public List<String> getVariables() {
        return List.of(this.getExp1().getVariables().toString(), this.exp2.getVariables().toString());
    }
}